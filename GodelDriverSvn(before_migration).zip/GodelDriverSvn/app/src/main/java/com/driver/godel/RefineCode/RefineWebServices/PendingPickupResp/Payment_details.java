package com.driver.godel.RefineCode.RefineWebServices.PendingPickupResp;

/**
 * Created by Ajay2.Sharma on 7/13/2018.
 */

public class Payment_details {
}
