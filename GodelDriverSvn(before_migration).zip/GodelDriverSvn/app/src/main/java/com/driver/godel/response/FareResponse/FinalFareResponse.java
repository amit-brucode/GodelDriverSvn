package com.driver.godel.response.FareResponse;

/**
 * Created by Ajay2.Sharma on 07-Sep-17.
 */

public class FinalFareResponse
{
    private int response;

    private Data data;

    public int getResponse()
    {
        return response;
    }

    public void setResponse(int response)
    {
        this.response = response;
    }

    public Data getData()
    {
        return data;
    }

    public void setData(Data data)
    {
        this.data = data;
    }
}
