package com.driver.godel.response;

/**
 * Created by QSYS\simarjot.singh on 21/6/17.
 */

public class LoginData
{
    private String vechicle_name;

    private String is_dev;

    private String driver_phone;

    private String driver_image;

    private String driver_app_notification;

    private String driver_name;

    private String driver_unique_id;

    private String vehicle;

    private String vechicle_type;

    private String password;

    private String vehicle_id_fk;

    private String driver_email;

    private String id;

    private String last_recieve_package_date_time;

    private String active_package_code;

    private String driver_lng;

    private String name;

    private String driver_status;

    private String created_at;

    private String vechicle_color;

    private String created_by;

    private String isVerified;

    private String country_id;

    private String confirmation_code;

    private String driver_status_change_time;

    private String code;

    private String source_lng;

    private String driver_lat;

    private String updated_at;

    private String active_type;

    private String driver_active_status;

    private String source_lat;

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getVechicle_name ()
{
    return vechicle_name;
}

    public void setVechicle_name (String vechicle_name)
    {
        this.vechicle_name = vechicle_name;
    }

    public String getIs_dev ()
    {
        return is_dev;
    }

    public void setIs_dev (String is_dev)
    {
        this.is_dev = is_dev;
    }

    public String getDriver_phone ()
    {
        return driver_phone;
    }

    public void setDriver_phone (String driver_phone)
    {
        this.driver_phone = driver_phone;
    }

    public String getDriver_image ()
    {
        return driver_image;
    }

    public void setDriver_image (String driver_image)
    {
        this.driver_image = driver_image;
    }

    public String getDriver_app_notification ()
    {
        return driver_app_notification;
    }

    public void setDriver_app_notification (String driver_app_notification)
    {
        this.driver_app_notification = driver_app_notification;
    }

    public String getDriver_name ()
    {
        return driver_name;
    }

    public void setDriver_name (String driver_name)
    {
        this.driver_name = driver_name;
    }

    public String getDriver_unique_id ()
    {
        return driver_unique_id;
    }

    public void setDriver_unique_id (String driver_unique_id)
    {
        this.driver_unique_id = driver_unique_id;
    }

    public String getVehicle ()
    {
        return vehicle;
    }

    public void setVehicle (String vehicle)
    {
        this.vehicle = vehicle;
    }

    public String getVechicle_type ()
{
    return vechicle_type;
}

    public void setVechicle_type (String vechicle_type)
    {
        this.vechicle_type = vechicle_type;
    }

    public String getPassword ()
    {
        return password;
    }

    public void setPassword (String password)
    {
        this.password = password;
    }

    public String getVehicle_id_fk ()
    {
        return vehicle_id_fk;
    }

    public void setVehicle_id_fk (String vehicle_id_fk)
    {
        this.vehicle_id_fk = vehicle_id_fk;
    }

    public String getDriver_email ()
    {
        return driver_email;
    }

    public void setDriver_email (String driver_email)
    {
        this.driver_email = driver_email;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getLast_recieve_package_date_time ()
{
    return last_recieve_package_date_time;
}

    public void setLast_recieve_package_date_time (String last_recieve_package_date_time)
    {
        this.last_recieve_package_date_time = last_recieve_package_date_time;
    }

    public String getActive_package_code ()
    {
        return active_package_code;
    }

    public void setActive_package_code (String active_package_code)
    {
        this.active_package_code = active_package_code;
    }

    public String getDriver_lng ()
    {
        return driver_lng;
    }

    public void setDriver_lng (String driver_lng)
    {
        this.driver_lng = driver_lng;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getDriver_status ()
    {
        return driver_status;
    }

    public void setDriver_status (String driver_status)
    {
        this.driver_status = driver_status;
    }

    public String getCreated_at ()
    {
        return created_at;
    }

    public void setCreated_at (String created_at)
    {
        this.created_at = created_at;
    }

    public String getVechicle_color ()
{
    return vechicle_color;
}

    public void setVechicle_color (String vechicle_color)
    {
        this.vechicle_color = vechicle_color;
    }

    public String getCreated_by ()
    {
        return created_by;
    }

    public void setCreated_by (String created_by)
    {
        this.created_by = created_by;
    }

    public String getIsVerified ()
    {
        return isVerified;
    }

    public void setIsVerified (String isVerified)
    {
        this.isVerified = isVerified;
    }

    public String getCountry_id ()
    {
        return country_id;
    }

    public void setCountry_id (String country_id)
    {
        this.country_id = country_id;
    }

    public String getConfirmation_code ()
    {
        return confirmation_code;
    }

    public void setConfirmation_code (String confirmation_code)
    {
        this.confirmation_code = confirmation_code;
    }

    public String getDriver_status_change_time ()
    {
        return driver_status_change_time;
    }

    public void setDriver_status_change_time (String driver_status_change_time)
    {
        this.driver_status_change_time = driver_status_change_time;
    }

    public String getCode ()
    {
        return code;
    }

    public void setCode (String code)
    {
        this.code = code;
    }

    public String getSource_lng ()
    {
        return source_lng;
    }

    public void setSource_lng (String source_lng)
    {
        this.source_lng = source_lng;
    }

    public String getDriver_lat ()
    {
        return driver_lat;
    }

    public void setDriver_lat (String driver_lat)
    {
        this.driver_lat = driver_lat;
    }

    public String getUpdated_at ()
    {
        return updated_at;
    }

    public void setUpdated_at (String updated_at)
    {
        this.updated_at = updated_at;
    }

    public String getActive_type ()
    {
        return active_type;
    }

    public void setActive_type (String active_type)
    {
        this.active_type = active_type;
    }

    public String getDriver_active_status ()
    {
        return driver_active_status;
    }

    public void setDriver_active_status (String driver_active_status)
    {
        this.driver_active_status = driver_active_status;
    }

    public String getSource_lat ()
    {
        return source_lat;
    }

    public void setSource_lat (String source_lat)
    {
        this.source_lat = source_lat;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [vechicle_name = "+vechicle_name+", is_dev = "+is_dev+", driver_phone = "+driver_phone+", driver_image = "+driver_image+", driver_app_notification = "+driver_app_notification+", driver_name = "+driver_name+", driver_unique_id = "+driver_unique_id+", vehicle = "+vehicle+", vechicle_type = "+vechicle_type+", password = "+password+", vehicle_id_fk = "+vehicle_id_fk+", driver_email = "+driver_email+", id = "+id+", last_recieve_package_date_time = "+last_recieve_package_date_time+", active_package_code = "+active_package_code+", driver_lng = "+driver_lng+", name = "+name+", driver_status = "+driver_status+", created_at = "+created_at+", vechicle_color = "+vechicle_color+", created_by = "+created_by+", isVerified = "+isVerified+", country_id = "+country_id+", confirmation_code = "+confirmation_code+", driver_status_change_time = "+driver_status_change_time+", code = "+code+", source_lng = "+source_lng+", driver_lat = "+driver_lat+", updated_at = "+updated_at+", active_type = "+active_type+", driver_active_status = "+driver_active_status+", source_lat = "+source_lat+"]";
    }
}

