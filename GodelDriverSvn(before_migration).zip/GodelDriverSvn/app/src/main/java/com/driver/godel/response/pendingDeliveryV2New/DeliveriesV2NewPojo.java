package com.driver.godel.response.pendingDeliveryV2New;

/**
 * Created by root on 24/2/18.
 */

public class DeliveriesV2NewPojo
{
    /*private String preferred_deliver_time;

    private String is_warehouse_dropoff;

    private String delivery_type;

    private String is_warehouse_pickup;

    private String booking_id;

    private String is_cancel;

    private String min_delivery_time;

    private String delivery_session;

    private String booking_type;

    private String booking_delivery_datetime;

    private String booking_note;

    private String booking_code;

    private String booking_pickup_datetime;

    //WareHouse Details
    private String whId;
    private String whStateId;
    private String whPhone;
    private String whUpdatedAt;
    private String whAddress;
    private String whName;
    private String whCreatedAt;
    private String whLongtitude;
    private String whLatitude;
    private String whUserEmail;

    //Location Details
    private String dropoff_location_lat;
    private String pickup_street;
    private String fk_booking_id;
    private String pickup_location_lng;
    private String dropoff_house_no;
    private String pickup_house_no;
    private String dropoff_location;
    private String pickup_landmark;
    private String fk_package_code;
    private String id;
    private String updated_at;
    private String dropoff_location_datetime;
    private String pickup_location_lat;
    private String dropoff_street;
    private String created_at;
    private String dropoff_landmark;
    private String pickup_datetime;
    private String dropoff_location_lng;
    private String pickup_location;

    //Package Details
    private String handle_by;
    private String final_price;
    private String package_status;
    private String package_description;
    private String pop_image;
    private String[] payment_details;
    private String payment_status;
    private String feedback;
    private String package_code;
    private String driver_device_token;
    private String created_at;
    private String driver_id;
    private String partner_user_id;
    private String tracking_id;
    private String signature;
    private String package_height;
    private String package_depth;
    private String fk_booking_id;
    private String package_quantity;
    private String warehouse_user_id;
    private String pod_image;
    private String sign_name;
    private String estimate_price;
    private String updated_at;
    private String package_est_value;
    private String package_width;
    private String package_id;
    private String send_selected_driver;
    private String package_cancel;
    private String rating;
    private String package_length;
    private String package_weight;

    //User Details
    private String is_verified_by_admin;
    private String remember_token;
    private String vehicle_type;
    private String user_app_notification;
    private String user_email;
    private String type;
    private String phone_verify;
    private String password;
    private String id;
    private String trading_address;
    private String credit_limit;
    private String company_name;
    private String trading_licence_no;
    private String token;
    private String email_verify;
    private String name;
    private String created_at;
    private String gender;
    private String user_image;
    private String sinch_code;
    private String login_type;
    private null company_registration_no;
    private String user_status;
    private null agent_id;
    private String add_by_agent;
    private null nature_of_business;
    private String updated_at;
    private null validate_code;

    private String source;

    private String user_phone;

    private null dob;

    private null secondary_contact_no;

    private null facebook_id;*/











}
