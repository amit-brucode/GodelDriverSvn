package com.driver.godel.response.pendingResponse;

/**
 * Created by root on 24/2/18.
 */

public class Warehouse_pickup_address {
    private String id;

    private String state_id;

    private String phone;

    private String updated_at;

    private String address;

    private String name;

    private String created_at;

    private String longtitude;

    private String latitude;

    private String user_email;

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getState_id ()
    {
        return state_id;
    }

    public void setState_id (String state_id)
    {
        this.state_id = state_id;
    }

    public String getPhone ()
    {
        return phone;
    }

    public void setPhone (String phone)
    {
        this.phone = phone;
    }

    public String getUpdated_at ()
    {
        return updated_at;
    }

    public void setUpdated_at (String updated_at)
    {
        this.updated_at = updated_at;
    }

    public String getAddress ()
    {
        return address;
    }

    public void setAddress (String address)
    {
        this.address = address;
    }

    public String getName ()
    {
        return name;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public String getCreated_at ()
    {
        return created_at;
    }

    public void setCreated_at (String created_at)
    {
        this.created_at = created_at;
    }

    public String getLongtitude ()
    {
        return longtitude;
    }

    public void setLongtitude (String longtitude)
    {
        this.longtitude = longtitude;
    }

    public String getLatitude ()
    {
        return latitude;
    }

    public void setLatitude (String latitude)
    {
        this.latitude = latitude;
    }

    public String getUser_email ()
    {
        return user_email;
    }

    public void setUser_email (String user_email)
    {
        this.user_email = user_email;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [id = "+id+", state_id = "+state_id+", phone = "+phone+", updated_at = "+updated_at+", address = "+address+", name = "+name+", created_at = "+created_at+", longtitude = "+longtitude+", latitude = "+latitude+", user_email = "+user_email+"]";
    }
}
