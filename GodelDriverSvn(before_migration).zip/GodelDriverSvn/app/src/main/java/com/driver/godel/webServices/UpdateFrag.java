//package com.driver.godel.webServices;
//
///**
// * Created by root on 1/2/18.
// */
//
//public interface UpdateFrag
//{
//    public void updatefrag(Boolean isChecked);
//}
